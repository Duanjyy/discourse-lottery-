<!DOCTYPE html>
<html lang="zh-CN" >
<head>
    <meta name="viewport" content="width=device-width, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="chrome=1">
    <meta http-equiv="Content-Type" content="text/html; charset = UTF-8" />
    <title>互动友链</title>
    <style>
        body {
            overflow: hidden;
            background-color: #000000;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -o-user-select: none;
            -ms-user-select: none;
        }

        .gdtx img {
            position: absolute;
            left: -120px;
            top: -120px;
            width: 240px;
            height: 240px;
            border-radius: 150px;
        }
    </style>
</head>

<body>
<div id="canvas" style="width: 540px;height: 640px;"></div>
<script src="/themes/theme-hao/assets/libs/link/protoclass.min.js"></script>
<script src="/themes/theme-hao/assets/libs/link/box2d.min.js"></script>
<script src="/themes/theme-hao/assets/libs/link/Main.min.js">
</script>
</body>

</html>