<?php get_header(); ?>


    <div class="page" id="body-wrap">
        <!-- 头部导航栏 -->
        <header class="not-top-img" id="page-header">
            <?php get_template_part("modules/nav"); ?>
        </header>
        <main class="layout hide-aside" id="content-inner">
            <div id="page">
                <div class="music-mask"></div>
                <h1 class="page-title">音乐馆</h1>
                <div id="anMusic-page">
                    <!-- <div id="anMusicBtnGetSong"><i class="anzhiyufont anzhiyu-icon-shuffle"></i></div>
                    <div id="anMusicRefreshBtn"><i class="anzhiyufont anzhiyu-icon-arrows-rotate"></i></div>
                    <div id="anMusicSwitching"><i class="anzhiyufont anzhiyu-icon-repeat"></i></div> -->
                    <div id="anMusic-page-meting">
                        <meting-js type="playlist" mutex="true" preload="auto"
                                   theme="var(--heo-main)" order="list" list-max-height="calc(100vh - 169px)!important">
                        </meting-js>
                    </div>
                </div>
            </div>


            <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/libs/aplayer/music.css" >


        </main>
        <!-- 底部 -->
        <?php get_template_part("modules/footer"); ?>
    </div>


<?php get_footer(); ?>
