<!-- 侧栏，主要是手机端时会使用 -->
<div id="sidebar">
    <div id="menu-mask"></div>
    <div id="sidebar-menus">
        <span class="sidebar-menu-item-title">功能</span>
        <div class="sidebar-menu-item">
            <a class="darkmode_switchbutton menu-child" href="javascript:void(0);" onclick="rm.switchDarkMode()"
               rel="external nofollow" title="显示模式切换">
                <i class="haofont hao-icon-moon" style="font-size: 0.9rem;"></i>
                <span>显示模式</span>
            </a>
        </div>
        <th:block <?php /* if(${not #strings.isEmpty(theme.config.nav.leftMenu) && theme.config.nav.menus.phone_leftMenu}) */ ?>
                  th:with="leftMenu = ${menuFinder.getByName(theme.config.nav.leftMenu)}">
            <div class="back-menu-list-groups">
                <div class="back-menu-list-group" <?php /* loop */ ?>>

                    <th:block <?php /* if(${not #lists.isEmpty(menuItem.children)}) */ ?>>
                        <!-- 菜单必须有子项才会展示 -->
                        <div class="back-menu-list-title" th:text="${menuItem.status.displayName}"></div>
                        <div class="back-menu-list">
                            <th:block <?php /* loop */ ?>>
                                <a class="back-menu-item" rel="external nofollow"
                                   target="_blank" th:href="@{${childMenu.status.href}}">
                                    <!-- icon -->
                                    <img <?php /* if(${!#strings.isEmpty(#annotations.getOrDefault(childMenu, 'icon', ''))}) */ ?>
                                         class="back-menu-item-icon"
                                         th:src="${#annotations.getOrDefault(childMenu, 'icon', '')}">
                                    <span class="back-menu-item-text" th:text="${childMenu.status.displayName}"></span>
                                </a>
                            </th:block>
                        </div>

                    </th:block>
                </div>

            </div>
        </th:block>
        <th:block <?php /* if(${not #lists.isEmpty(menuFinder.getPrimary().menuItems) && theme.config.nav.menus.phone_menu}) */ ?>
        >
            <div class="menus_items">
                <div class="menus_item" <?php /* loop */ ?>>
                    <th:block <?php /* if(${not #lists.isEmpty(menuItem.children)}) */ ?>>
                        <a class="site-page" href="javascript:void(0);" rel="external nofollow">
                            <span th:text="${menuItem.status.displayName}"></span>
                        </a>
                        <th:block <?php /* if(${not #lists.isEmpty(menuItem.children)}) */ ?>>
                            <ul class="menus_item_child">
                                <li <?php /* loop */ ?>>
                                    <a class="site-page child" th:href="@{${childMenu.status.href}}">
                                        <th:block <?php /* if(${!theme.config.nav.menus.enable_ali_iconfont_symbol_header}) */ ?>>
                                            <i <?php /* if(${!#strings.isEmpty(#annotations.getOrDefault(childMenu, 'icon', ''))}) */ ?>
                                               th:class="${#annotations.getOrDefault(childMenu, 'icon', '')}"></i>
                                        </th:block>
                                        <th:block <?php /* if(${theme.config.nav.menus.enable_ali_iconfont_symbol_header}) */ ?>>
                                            <svg class="ali_icon" aria-hidden="true">
                                                <use th:href="${#annotations.getOrDefault(childMenu, 'icon','jiewen joe-icon-zuzhijiagou')}"></use>
                                            </svg>
                                        </th:block>
                                        <span th:text="${childMenu.status.displayName}"></span>
                                    </a>
                                </li>
                            </ul>
                        </th:block>
                    </th:block>
                </div>
            </div>
        </th:block>
        <span class="sidebar-menu-item-title">标签</span>
        <div class="card-widget card-tags card-archives card-webinfo card-allinfo"
             th:with="tags = ${tagFinder.list(1,theme.config.sidebar.tagQuantity)}">
            <div class="item-headline"></div>
            <div class="card-tag-cloud">
                <a class="tag-item" style="font-size:1em" <?php /* loop */ ?>
                   th:href="@{${tag.status.permalink}}"
                   th:title="${tag.spec.displayName}">
                    <!-- 角标 -->
                    [[${tag.spec.displayName}]]<sup th:text="${tag.status.visiblePostCount}"></sup>
                </a>
            </div>
        </div>
    </div>
</div>
