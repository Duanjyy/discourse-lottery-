<!-- 页脚模块 -->
<footer id="footer" xmlns:th="http://www.w3.org/1999/xhtml">

    <div id="heo-footer-bar" <?php /* if(${theme.config.footer.footer_bar.footer_bar_enable}) */ ?>>
        <div class="footer-logo"></div>
        <div class="footer-bar-description"></div>
        <a class="footer-bar-link" href="/" data-pjax-state="">了解更多</a>
    </div>

    <!-- 社交链接，需要填入 href class title -->
    <div id="footer_deal">
        
            <a rel="external nofollow" target="_blank" <?php /* loop */ ?>>
                <i <?php /* if(${socialMedia.option_social_data == 'icon'  || #strings.isEmpty(socialMedia.option_social_data)}) */ ?>></i>

            </a>
        

        <img <?php /* if(${not #strings.isEmpty(theme.config.footer.social_media.centerImg)}) */ ?> class="footer_mini_logo" title="返回顶部" onclick="btf.scrollToDest(0, 500)">

        
            <a rel="external nofollow" target="_blank" <?php /* loop */ ?>>
                <i <?php /* if(${socialMedia.option_social_data == 'icon' || #strings.isEmpty(socialMedia.option_social_data)}) */ ?>></i>

            </a>
        
    </div>

    <!-- 相关地址  -->

        <div id="heo-footer" <?php /* if(${not #lists.isEmpty(footMenu.menuItems)}) */ ?>>
            <div class="footer-group" <?php /* loop */ ?>>
                <h3 class="footer-title"></h3>
                <div class="footer-links">
                    <a class="footer-item" <?php /* loop */ ?>>
                    </a>
                </div>
            </div>
            <div <?php /* if(${theme.config.footer.footer_group.enable_footer_group}) */ ?> class="footer-group">
                <div class="footer-title-group">
                    <h3 class="footer-title">友链</h3>
                    <a class="random-friends-btn" id="footer-random-friends-btn"
                       href="javascript:heo.addFriendLinksInFooter();" rel="external nofollow" title="换一批友情链接"
                       data-pjax-state="external"><i class="haofont hao-icon-arrow-rotate-right" style="font-size: 16px;"></i></a>
                </div>
                <div class="footer-links" id="friend-links-in-footer"></div>
            </div>
        </div>

    
    <!-- 底部 banner -->
    <halo:footer />

    
    <div class="copyright">
        ©<?php echo get_theme_mod("hao_siteStartTime", "2023"); ?> - <?php echo date("Y"); ?> By <?php bloginfo("name"); ?>
    </div>
    
    <div <?php /* if(${theme.config.footer.footerContent.style_one.runtime_enable}) */ ?> id="workboard"></div>
    <p <?php /* if(${theme.config.footer.footerContent.style_one.bdageitem_enable && not #lists.isEmpty(theme.config.footer.footerContent.style_one.bdageitem)}) */ ?>
       id="ghbdages" style="width:60%;margin: 0 auto 0;">
        <a class="github-badge" <?php /* loop */ ?> target="_blank"
           style="margin-inline:5px">
            <img />
        </a>
    </p>
    <span <?php /* if(${!theme.config.footer.footerContent.default_enable_group.default_enable}) */ ?> style="padding: 5px 5px;">

    </span>

    <style>
        .copyright,
        #ghbdages,
        #workboard {
            text-align: center;
        }
    </style>

    <style
            <?php /* if(${(theme.config.footer.footerContent.style_one.owner_enable
            || (not #lists.isEmpty(theme.config.footer.footerContent.style_one.bdageitem) && theme.config.footer.footerContent.style_one.bdageitem_enable )
            || theme.config.footer.footerContent.style_one.runtime_enable)
        && theme.config.footer.footerContent.default_enable_group.default_enable}) */ ?>>
        #heo-footer {
            margin-bottom: 1rem;
        }
    </style>

    <div <?php /* if(${theme.config.footer.footerContent.default_enable_group.default_enable}) */ ?> id="footer-banner">
        <div class="footer-banner-links">
            <div class="footer-banner-left">
                <div id="footer-banner-tips">
                    <div style="display: flex;flex-direction: row;align-items: center;">

                            ©<?php echo get_theme_mod("hao_siteStartTime", "2023"); ?> - 

                            ©<?php echo date("Y"); ?>
                        
                        By <a class="footer-banner-link" href="/" target="_blank"><?php bloginfo("name"); ?></a>
                    </div>
                </div>
            </div>
            
            <div class="footer-banner-right">
                <a class="footer-banner-link cloud" href="https://www.aliyun.com/" rel="noopener external nofollow noreferrer noopener" target="_blank">
                    <span>本网站由</span>&nbsp;&nbsp;
                    <img alt="aliyun" src="<?php echo get_template_directory_uri(); ?>/assets/images/footer/aliyun.png" class="cloud-logo" />
                    &nbsp;&nbsp;<span>提供CDN加速/云存储服务</span>
                </a>
                <a class="footer-banner-link" href="/rss.xml">订阅</a>
                <a class="footer-banner-link" href="https://github.com/liuzhihang/halo-theme-hao">主题</a>
                <a class="footer-banner-link" href="/about">关于</a>
                <a class="footer-banner-link cc" title="cc协议">
                    <i class="haofont hao-icon-copyright-line"></i>
                    <i class="haofont hao-icon-creative-commons-by-line"></i>
                    <i class="haofont hao-icon-creative-commons-nc-line"></i>
                    <i class="haofont hao-icon-creative-commons-nd-line"></i>
                </a>
            </div>
    
        </div>
    </div>


    <!-- 右下角 snackbar 弹窗 -->
    <div <?php /* if(${theme.config.tool.snackbar.switch}) */ ?> class="needEndHide" id="cookies-window">
        <div class="cookies-window-title"></div>
        <div class="cookies-window-content"><span class="cookies-tip"></span>
            <a class="cookies-link" data-pjax-state=""><i
                    class="bber-gotobb haofont hao-icon-circle-arrow-right"></i></a>
        </div>
    </div>
    <div id="quit-box" onclick="RemoveRewardMask()"></div>

    <!--评论弹幕弹窗 -->
    <div class="comment-barrage needEndHide" style="display: none;"></div>

    <style>
        a.footer-banner-link.cloud {
            display: flex;
            align-items: center;
        }
        img.cloud-logo {
            height: 32px;
        }
    </style>

        <style>
            @media screen and (min-width: 1300px) {
                #footer {
                    background: linear-gradient(180deg, var(--heo-card-bg-none) 0%, #fff0 25%);
                    margin-top: 0.5rem;
                    display: flex;
                    flex-direction: column;
                }
            }
            
            @media screen and (max-width: 1300px) {
                #footer {
                    background: linear-gradient(180deg, var(--heo-background) 0%, #fff0 25%);
                    margin-top: 0;
                    z-index: 3;
                }
            }
        
        </style>
    
    
</footer>


