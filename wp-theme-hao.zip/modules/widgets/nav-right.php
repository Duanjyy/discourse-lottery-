<!-- 导航栏菜单栏 -->
<div id="nav-right">

    <!-- 功能都需要添加开关 -->

    <!-- 随机前往一个开往项目网站 -->
    <div class="nav-button only-home" id="travellings_button" title="随机前往一个开往项目网站" <?php /* if() */ ?>>
        <a class="site-page" href="https://www.travellings.cn/go.html"  rel="external nofollow"
           title="随机前往一个开往项目网站">
            <i class="haofont hao-icon-eicon_train-line"></i>
        </a>
    </div>

    <div class="nav-button" id="randomPost_button" <?php /* if() */ ?>>
        <a class="site-page" href="javascript:void(0);" onclick="toRandomPost()" title="随机文章">
            <i class="haofont hao-icon-signal-tower-fill"></i>
        </a>
    </div>

    <!-- 切换模式 -->
    <div class="nav-button" id="darkmode_button" <?php /* if() */ ?>>
        <a class="console_switchbutton" href="javascript:void(0);"  onclick="navFn.switchDarkMode();" rel="external nofollow"
           title="切换模式 - 日夜交替，黑白互换。">
            <i class="haofont hao-icon-moon-clear-fill" style="font-size: 1rem;"></i>
        </a>
    </div>

    <!-- 搜索使用搜索插件 -->
    <div class="nav-button" id="search-button" <?php /* if() */ ?>>
        <a class="site-page social-icon search" href="javascript:SearchWidget.open();" rel="external nofollow"
           title="站内搜索">
            <i class="haofont hao-icon-search--line"></i>
        </a>
    </div>

    <div <?php /* if() */ ?> class="console-button" tabindex="-1">
        <span class="site-page nav-login">
            <i sec:authorize="isAnonymous()" class="haofont hao-icon-zhanghao1 " style="font-size: 19.5px;"></i>
            <img sec:authorize="isAuthenticated()"
                 style=" width: 24px; height: 24px; border-radius: 9999px" />
        </span>
        <div class="back-menu-list-groups">
            <div class="back-menu-list-group" style="margin: -4px -9px -4px -18px">
                <div class="back-menu-list">
                    <th:block sec:authorize="isAuthenticated()">
                        <a class="back-menu-item" rel="external nofollow" target="_blank" href="/console">
                            <span class="back-menu-item-text">控制台</span>
                        </a>
                        <a class="back-menu-item" rel="external nofollow" href="/logout">
                            <span class="back-menu-item-text">退出登录</span>
                        </a>
                    </th:block>
                    <a sec:authorize="isAnonymous()" class="back-menu-item" rel="external nofollow" target="_blank"
                       href="/login"
                       onclick="this.href = '/login?redirect_uri=' + encodeURIComponent(window.location.href)">
                        <span class="back-menu-item-text">登录</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div <?php /* if() */ ?> class="nav-button" id="nav-console">
        <a class="console_switchbutton" href="javascript:void(0);" onclick="heo.showConsole()" rel="external nofollow"
           title="显示中控台">
            <i class="haofont hao-icon-dashboard"></i>
        </a>
    </div>

    <div class="nav-button" id="nav-totop" onclick="btf.scrollToDest(0,500)">
        <a class="totopbtn">
            <i class="haofont hao-icon-arrow-up" style="font-size: 1rem;"></i><span id="percent">0</span>
        </a>
    </div>

    <div id="toggle-menu">
        <a class="site-page">
            <i class="haofont hao-icon-bars"></i>
        </a>
    </div>
</div>
