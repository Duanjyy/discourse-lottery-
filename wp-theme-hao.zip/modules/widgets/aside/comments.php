<!-- 最新评论 -->
<div class="card-widget card-recent-post" >
    <a <?php /* if(${not #strings.isEmpty(theme.config.sidebar.newcomment.newcommentUrl)}) */ ?>
       th:onclick="pjax.loadUrl([[${theme.config.sidebar.newcomment.newcommentUrl}]])"
       title="查看更多"
       class="card-more-btn"
       style="cursor:pointer" draggable="false"><i class="haofont hao-icon-chevron-right"></i></a>
    <div class="item-headline"><i class="haofont hao-icon-chat--fill" style="font-size: 19px;"></i><span>最新评论</span></div>
    <div class="aside-list" id="newcomm">
        <th:block <?php /* if(${#strings.equals(theme.config.comments.use, 'commentWidget') }) */ ?>
                  th:with="newcommentnumber = ${#conversions.convert(theme.config.sidebar.newcomment.newcommentnumber, 'java.lang.Integer') >= 0 ?  theme.config.sidebar.newcomment.newcommentnumber : 5}">
            <div <?php /* loop */ ?> class="aside-list-item"
                 th:with="page = ${comment.spec.subjectRef.kind == 'Post' ? postFinder.getByName(comment.spec.subjectRef.name) :
                comment.spec.subjectRef.kind == 'SinglePage' && not #strings.contains('photos,links,moments,equipment', comment.spec.subjectRef.name) ? singlePageFinder.getByName(comment.spec.subjectRef.name) : null},
                url = ${page == null? '/' : page.status.permalink + '#comment-' + comment.metadata.name}">
                <span th:text="${commentIndex}"></span>
                <a class="thumbnail" th:href="${url}" data-pjax-state="">
                    <img alt="头像"
                         th:with=" img =${#strings.isEmpty(comment.owner.avatar)? theme.config.sidebar.newcomment.providerMirror+'/avatar/'+comment.spec.owner.annotations['email-hash'] :comment.owner.avatar}"
                         th:src="${isLazyload ? '' : img}" th:data-lazy-src="${ isLazyload ? img : ''}">
                </a>
                <div class="content">
                    <a class="comment"
                       style="display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;overflow: hidden;"
                       th:href="${url}" th:title="${comment.spec.content}" th:text="${comment.spec.content}"
                       data-pjax-state="">

                    </a>
                    <div class="name">
                        <span th:text="${comment.owner.displayName + ' / '}">stonewu / </span>
                        <time
                                th:datetime="${#dates.format(comment.metadata.creationTimestamp, 'yyyy-MM-dd HH:mm:ss')}"></time>
                    </div>
                </div>
            </div>
        </th:block>
    </div>
</div>
