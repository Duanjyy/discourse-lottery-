<!-- 爱发电赞助 -->
<div>
    <div class="card-widget card-power">
        <div class="item-headline"><i class="haofont hao-icon-aifadian-line"></i><span>爱发电赞助</span>
            <a class="power-charge" target="_blank" title="赞助博主">赞助
            </a>
        </div>
        <a id="power-star" rel="external nofollow" target="_blank" title="推荐博主">

        </a>
        <div class="power-list">
            <div class="power-item">
                <div class="power-item-body">
                    <div class="power-item-link" id="power-item-link">

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
