<!-- 侧边栏站点信息统计 -->

<th:block  th:with="stats = ${siteStatsFinder.getStats()}">

    <!--    <div class="item-headline"><i class="haofont icon-icon-sidebar-scxmtj"></i><span>统计</span></div>-->
    <div class="webinfo">
        <div class="webinfo-item">
            <div class="webinfo-item-title"><i class="haofont hao-icon-file-lines"></i>
                <div class="item-name">文章数 :</div>
            </div>
            <div class="item-count" th:text="${stats.post}"></div>
        </div>
        <!-- <div class="webinfo-item">
            <div class="webinfo-item-title"><i class="haofont icon-sliders"></i>
                <div class="item-name">分类数 :</div>
            </div>
            <div class="item-count" th:text="${stats.category}"></div>
        </div> -->
        <!-- <div class="webinfo-item">
            <div class="webinfo-item-title"><i class="haofont icon-comment-alt"></i>
                <div class="item-name">评论数 :</div>
            </div>
            <div class="item-count" th:text="${stats.comment}"></div>
        </div> -->
        <div class="webinfo-item">
            <div class="webinfo-item-title"><i class="haofont hao-icon-bullseye"></i>
                <div class="item-name">访问量 :</div>
            </div>
            <div class="item-count" th:text="${stats.visit}"></div>
        </div>
        <div class="webinfo-item">
            <div class="webinfo-item-title"><i class="haofont hao-icon-stopwatch"></i>
                <div class="item-name">建站天数 :</div>
            </div>
            <div class="item-count" th:text="${theme.config.basics.siteStartTime}"  id="runtimeshow"></div>
        </div>
        <!-- <div class="webinfo-item">
            <div class="webinfo-item-title"><i class="item-icon fas fa-font"></i>
                <div class="item-name">全站字数 :</div>
            </div>
            <div class="item-count">606.7k</div>
        </div> -->
    </div>
</th:block>
