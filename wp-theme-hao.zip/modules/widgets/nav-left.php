<!-- 导航栏左侧 -->
<div id="blog_name" >

    <th:block <?php /* if(${not #strings.isEmpty(theme.config.nav.leftMenu) && theme.config.nav.menus.pc_leftMenu}) */ ?>
              th:with="leftMenu = ${menuFinder.getByName(theme.config.nav.leftMenu)}">
        <!-- 菜单栏左侧按钮，没有配置时，则不展示-->
        <div class="back-home-button" tabindex="-1"
             <?php /* if(${not #lists.isEmpty(leftMenu)}) */ ?>>

            <i class="back-home-button-icon haofont hao-icon-apps-fill" style="font-size: 1rem"></i>
            <div class="back-menu-list-groups">
                <div class="back-menu-list-group" <?php if (have_posts()) : while (have_posts()) : the_post(); ?>>
                    <!-- 菜单必须有子项才会展示 -->
                    <th:block <?php /* if(${not #lists.isEmpty(menuItem.children)}) */ ?>>
                        <div class="back-menu-list-title" th:text="${menuItem.status.displayName}"></div>
                        <div class="back-menu-list">
                            <th:block <?php if (have_posts()) : while (have_posts()) : the_post(); ?>>
                                <a class="back-menu-item" rel="external nofollow"
                                   th:target="${childMenu.spec.target?.value}" th:href="@{${childMenu.status.href}}">
                                    <!-- icon 预留 -->
                                    <img <?php /* if(${!#strings.isEmpty(#annotations.getOrDefault(childMenu, 'icon', ''))}) */ ?>
                                         class="back-menu-item-icon"
                                         th:src="${#annotations.getOrDefault(childMenu, 'icon', '')}">
                                    <span class="back-menu-item-text" th:text="${childMenu.status.displayName}"></span>
                                </a>
                            </th:block>
                        </div>
                    </th:block>

                </div>
            </div>
        </div>
    </th:block>
    <!-- 返回主页 -->
    <!-- 这里可以指定使用什么作为图标，默认使用站点名称 -->
    <a href="/" id="site-name" title="返回博客主页">
        <span th:utext="${#strings.isEmpty(theme.config.basics.siteTitle)} ? <?php bloginfo("name"); ?> : ${theme.config.basics.siteTitle}"></span>
    </a>
</div>
