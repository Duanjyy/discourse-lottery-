<!-- 推荐文章 -->
<div class="topGroup" id="topGroup"
     th:with='topGroupPosts = ${postFinder.list(1,6)},
    postRandomImg=${#strings.contains(theme.config.layout.postRandomImg,"?") ? theme.config.layout.postRandomImg+"&" : theme.config.layout.postRandomImg+"?"}'>
    <div class="recent-post-group">
        <div class="recent-post-item" <?php /* loop */ ?>
             <?php /* if(${#strings.equals(theme.config.top.BannerRight.recommendPost, 'latest')}) */ ?>>

            <div class="post_cover" th:classappend="${iter.index % 2 == 0 ? 'left_radius' : 'right_radius'}">
                <a th:href="@{<?php the_permalink(); ?>}" th:title="<?php the_title(); ?>">
                    <span class="recent-post-top-text"
                          th:attr="onclick='pjax.loadUrl(\''+ @{<?php the_permalink(); ?>} +'\')'">荐</span>
                    <img class="post_bg"
                         th:with=' img = ${#strings.isEmpty(post.spec.cover) ? postRandomImg+post.spec.title : thumbnail.gen(post.spec.cover, "s")}'
                         th:alt="<?php the_title(); ?>" th:src="${isLazyload ? '' : img}"
                         th:data-lazy-src="${ isLazyload ? img : ''}" />
                </a>
            </div>
            <div class="recent-post-info">
                <a class="article-title" th:href="@{<?php the_permalink(); ?>}" th:text="<?php the_title(); ?>"
                   th:title="<?php the_title(); ?>">
                </a>
            </div>
        </div>
        <!-- 自定义的文章右上角的推荐文章 -->
        <div class="recent-post-item" <?php /* loop */ ?>
             <?php /* if(${#strings.equals(theme.config.top.BannerRight.recommendPost, 'custom') && not #strings.isEmpty(cuscomPost.post) }) */ ?>>
            <th:block th:with="post = ${postFinder.getByName(cuscomPost.post)}">
                <div class="post_cover" th:classappend="${iter.index % 2 == 0 ? 'left_radius' : 'right_radius'}">
                    <a th:href="@{<?php the_permalink(); ?>}" th:title="<?php the_title(); ?>">
                        <span class="recent-post-top-text"
                              th:attr="onclick='pjax.loadUrl(\''+ @{<?php the_permalink(); ?>} +'\')'">荐</span>
                        <img class="post_bg"
                             th:with='img = ${#strings.isEmpty(post.spec.cover) ? postRandomImg+post.spec.title : thumbnail.gen(post.spec.cover, "s")}'
                             th:alt="<?php the_title(); ?>" th:src="${isLazyload ? '' : img}"
                             th:data-lazy-src="${ isLazyload ? img : ''}" />
                    </a>
                </div>
                <div class="recent-post-info">
                    <a class="article-title" th:href="@{<?php the_permalink(); ?>}" th:text="<?php the_title(); ?>"
                       th:title="<?php the_title(); ?>">
                    </a>
                </div>
            </th:block>
        </div>
    </div>

    <!-- 今日推荐 -->
    <div class="todayCard" id="todayCard" <?php /* if(${theme.config.top.BannerRight.todayRecommend}) */ ?>
         th:attr="onclick='javascript:window.open(\''+ ${theme.config.top.BannerRight.todayRecommendContent.todayRecommendUrl} +'\')'">
        <div class="todayCard-info">
            <div class="todayCard-tips"
                 th:text="${theme.config.top.BannerRight.todayRecommendContent.todayRecommendxTitle}"></div>
            <div class="todayCard-title"
                 th:text="${theme.config.top.BannerRight.todayRecommendContent.todayRecommendTitle}"></div>
        </div>
        <div class="todayCard-cover"
             th:style="'background:url('+ ${theme.config.top.BannerRight.todayRecommendContent.todayRecommendCover} +') no-repeat center/cover'">
        </div>
        <div class="banner-button-group">
            <a class="banner-button" onclick="window.event.cancelBubble=!0;heo.hideTodayCard()">
                <i class="haofont hao-icon-circle-plus"></i>
                <span class="banner-button-text">更多推荐</span>
            </a>
        </div>
    </div>
</div>