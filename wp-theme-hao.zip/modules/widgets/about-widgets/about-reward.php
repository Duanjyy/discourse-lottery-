<div class="author-content" <?php /* if() */ ?>
     xmlns:th="http://www.w3.org/1999/xhtml">
    <div class="author-content-item single reward" id="about-reward">
        <div class="author-content-item-tips">致谢</div>
        <span class="author-content-item-title"></span>
        <div class="author-content-item-description">
            
        </div>

        <div <?php /* if() */ ?> class="about-reward">
            <div id="con"></div>
            <div id="TA-con" onclick="heo.rewardShowConsole()">
                <div id="text-con">
                    <div id="linght"></div>
                    <div id="TA"></div>
                </div>
            </div>
            <div id="tube-con">
                <svg viewBox="0 0 1028 385" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 77H234.226L307.006 24H790" stroke="#e5e9ef" stroke-width="20"></path>
                    <path d="M0 140H233.035L329.72 71H1028" stroke="#e5e9ef" stroke-width="20"></path>
                    <path d="M1 255H234.226L307.006 307H790" stroke="#e5e9ef" stroke-width="20"></path>
                    <path d="M0 305H233.035L329.72 375H1028" stroke="#e5e9ef" stroke-width="20"></path>
                    <rect y="186" width="236" height="24" fill="#e5e9ef"></rect>
                    <ellipse cx="790" cy="25.5" rx="25" ry="25.5" fill="#e5e9ef"></ellipse>
                    <circle r="14" transform="matrix(1 0 0 -1 790 25)" fill="white"></circle>
                    <ellipse cx="790" cy="307.5" rx="25" ry="25.5" fill="#e5e9ef"></ellipse>
                    <circle r="14" transform="matrix(1 0 0 -1 790 308)" fill="white"></circle>
                </svg>
                <div id="mask">
                    <svg viewBox="0 0 1028 385" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 77H234.226L307.006 24H790" stroke="#f25d8e" stroke-width="20"></path>
                        <path d="M0 140H233.035L329.72 71H1028" stroke="#f25d8e" stroke-width="20"></path>
                        <path d="M1 255H234.226L307.006 307H790" stroke="#f25d8e" stroke-width="20"></path>
                        <path d="M0 305H233.035L329.72 375H1028" stroke="#f25d8e" stroke-width="20"></path>
                        <rect y="186" width="236" height="24" fill="#f25d8e"></rect>
                        <ellipse cx="790" cy="25.5" rx="25" ry="25.5" fill="#f25d8e"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 25)" fill="white"></circle>
                        <ellipse cx="790" cy="307.5" rx="25" ry="25.5" fill="#f25d8e"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 308)" fill="white"></circle>
                    </svg>
                </div>
                <div id="orange-mask">
                    <svg viewBox="0 0 1028 385" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 77H234.226L307.006 24H790" stroke="#ffd52b" stroke-width="20"></path>
                        <path d="M0 140H233.035L329.72 71H1028" stroke="#ffd52b" stroke-width="20"></path>
                        <path d="M1 255H234.226L307.006 307H790" stroke="#ffd52b" stroke-width="20"></path>
                        <path d="M0 305H233.035L329.72 375H1028" stroke="#ffd52b" stroke-width="20"></path>
                        <rect y="186" width="236" height="24" fill="#ffd52b"></rect>
                        <ellipse cx="790" cy="25.5" rx="25" ry="25.5" fill="#ffd52b"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 25)" fill="white"></circle>
                        <ellipse cx="790" cy="307.5" rx="25" ry="25.5" fill="#ffd52b"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 308)" fill="white"></circle>
                    </svg>
                </div>

                    <p id="people">共<b></b>人</p>

                    <p id="people">共<b></b>人</p>
                

            </div>
        </div>
        <div class="reward-list-all" <?php /* if() */ ?>>

            <div class="reward-list-item" <?php /* loop */ ?>>
                <div <?php /* if() */ ?>>
                    <div>
                        <div class="reward-list-item-avatar">
                            <img>
                        </div>
                        <div style="z-index:20;float: left;" class="reward-list-item-avatar-group">
                            <div class="reward-list-item-name"></div>
                        </div>
                    </div>
                    <div class="reward-list-bottom-group">
                        <div <?php /* if() */ ?>
                             class="reward-list-item-money">¥
                            
                        </div>
                        <div <?php /* if() */ ?>
                             class="reward-list-item-money"
                             style="background: var(--heo-vip);">¥ 
                        </div>
                        <time class="datatime reward-list-item-time"></time>
                    </div>
                </div>
                <div <?php /* if() */ ?>>
                    <div class="reward-list-item-name"></div>
                    <div class="reward-list-bottom-group">
                        <div <?php /* if() */ ?>
                             class="reward-list-item-money">¥
                            
                        </div>
                        <div <?php /* if() */ ?>
                             class="reward-list-item-money"
                             style="background: var(--heo-vip);">¥ 
                        </div>
                        <time class="datatime reward-list-item-time"></time>
                    </div>
                </div>

            </div>

        </div>

            <a href="https://afdian.com/a/carolcoral" target="_blank"><span class="sponar_afdian">爱发电</span></a>
            <div class="reward-list-all" <?php /* if() */ ?>>
                <div class="reward-list-item" <?php /* loop */ ?>>
                    <div <?php /* if() */ ?>>
                        <div>
                            <div class="reward-list-item-avatar">
                                <img>
                            </div>
                            <div style="z-index:20;float: left;" class="reward-list-item-avatar-group">
                                <div class="reward-list-item-name"></div>
                            </div>
                        </div>
                        <div class="reward-list-bottom-group">
                            <div <?php /* if() */ ?>
                                 class="reward-list-item-money">¥
                                
                            </div>
                            <div <?php /* if() */ ?>
                                 class="reward-list-item-money"
                                 style="background: var(--heo-vip);">¥ 
                            </div>
                            <time class="datatime reward-list-item-time">
                                
                            </time>
                        </div>
                    </div>
                </div>
            </div>
        

    </div>
</div>
<style>
    span.sponar_afdian {
        font-size: 2em;
        color: antiquewhite;
    }
</style>
