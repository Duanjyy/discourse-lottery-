<div class="author-content" <?php /* if(${theme.config.aboutReward.aboutRewardEnable}) */ ?>
     xmlns:th="http://www.w3.org/1999/xhtml">
    <div class="author-content-item single reward" id="about-reward">
        <div class="author-content-item-tips">致谢</div>
        <span class="author-content-item-title">[[${theme.config.aboutReward.title}]]</span>
        <div class="author-content-item-description">
            [[${theme.config.aboutReward.content}]]
        </div>

        <div <?php /* if(${theme.config.aboutReward.reward.enable_reward}) */ ?> class="about-reward">
            <div id="con"></div>
            <div id="TA-con" onclick="heo.rewardShowConsole()">
                <div id="text-con">
                    <div id="linght"></div>
                    <div id="TA">[[${theme.config.aboutReward.reward.name}]]</div>
                </div>
            </div>
            <div id="tube-con">
                <svg viewBox="0 0 1028 385" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 77H234.226L307.006 24H790" stroke="#e5e9ef" stroke-width="20"></path>
                    <path d="M0 140H233.035L329.72 71H1028" stroke="#e5e9ef" stroke-width="20"></path>
                    <path d="M1 255H234.226L307.006 307H790" stroke="#e5e9ef" stroke-width="20"></path>
                    <path d="M0 305H233.035L329.72 375H1028" stroke="#e5e9ef" stroke-width="20"></path>
                    <rect y="186" width="236" height="24" fill="#e5e9ef"></rect>
                    <ellipse cx="790" cy="25.5" rx="25" ry="25.5" fill="#e5e9ef"></ellipse>
                    <circle r="14" transform="matrix(1 0 0 -1 790 25)" fill="white"></circle>
                    <ellipse cx="790" cy="307.5" rx="25" ry="25.5" fill="#e5e9ef"></ellipse>
                    <circle r="14" transform="matrix(1 0 0 -1 790 308)" fill="white"></circle>
                </svg>
                <div id="mask">
                    <svg viewBox="0 0 1028 385" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 77H234.226L307.006 24H790" stroke="#f25d8e" stroke-width="20"></path>
                        <path d="M0 140H233.035L329.72 71H1028" stroke="#f25d8e" stroke-width="20"></path>
                        <path d="M1 255H234.226L307.006 307H790" stroke="#f25d8e" stroke-width="20"></path>
                        <path d="M0 305H233.035L329.72 375H1028" stroke="#f25d8e" stroke-width="20"></path>
                        <rect y="186" width="236" height="24" fill="#f25d8e"></rect>
                        <ellipse cx="790" cy="25.5" rx="25" ry="25.5" fill="#f25d8e"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 25)" fill="white"></circle>
                        <ellipse cx="790" cy="307.5" rx="25" ry="25.5" fill="#f25d8e"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 308)" fill="white"></circle>
                    </svg>
                </div>
                <div id="orange-mask">
                    <svg viewBox="0 0 1028 385" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 77H234.226L307.006 24H790" stroke="#ffd52b" stroke-width="20"></path>
                        <path d="M0 140H233.035L329.72 71H1028" stroke="#ffd52b" stroke-width="20"></path>
                        <path d="M1 255H234.226L307.006 307H790" stroke="#ffd52b" stroke-width="20"></path>
                        <path d="M0 305H233.035L329.72 375H1028" stroke="#ffd52b" stroke-width="20"></path>
                        <rect y="186" width="236" height="24" fill="#ffd52b"></rect>
                        <ellipse cx="790" cy="25.5" rx="25" ry="25.5" fill="#ffd52b"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 25)" fill="white"></circle>
                        <ellipse cx="790" cy="307.5" rx="25" ry="25.5" fill="#ffd52b"></ellipse>
                        <circle r="14" transform="matrix(1 0 0 -1 790 308)" fill="white"></circle>
                    </svg>
                </div>

                <th:block <?php /* if(not ${pluginFinder.available('plugin-afdian')}) */ ?>>
                    <p id="people">共<b>[[${theme.config.aboutReward.reward_list.size()}]]</b>人</p>
                </th:block>
                <th:block <?php /* if(${pluginFinder.available('plugin-afdian')}) */ ?>>
                    <p id="people">共<b>[[${theme.config.aboutReward.reward_list.size()}+${afdianFinder
                        .listAllSponsor().data.list.size()}]]</b>人</p>
                </th:block>

            </div>
        </div>
        <div class="reward-list-all" <?php /* if(${not #lists.isEmpty(theme.config.aboutReward.reward_list)}) */ ?>
             th:with="authorRewardList = ${theme.config.aboutReward.reward_list}">

            <div class="reward-list-item" <?php if (have_posts()) : while (have_posts()) : the_post(); ?>>
                <div <?php /* if(${not #strings.isEmpty(authorReward.avatar)}) */ ?>>
                    <div>
                        <div class="reward-list-item-avatar">
                            <img th:src="${authorReward.avatar}" th:alt="${authorReward.name}">
                        </div>
                        <div style="z-index:20;float: left;" class="reward-list-item-avatar-group">
                            <div class="reward-list-item-name">[[${authorReward.name}]]</div>
                        </div>
                    </div>
                    <div class="reward-list-bottom-group">
                        <div <?php /* if(${#conversions.convert(authorReward.amount, 'java.math.BigDecimal') < #conversions.convert(theme.config.aboutReward.rewardNumber, 'java.math.BigDecimal')}) */ ?>
                             class="reward-list-item-money">¥
                            [[${authorReward.amount}]]
                        </div>
                        <div <?php /* if(${#conversions.convert(authorReward.amount, 'java.math.BigDecimal') >= #conversions.convert(theme.config.aboutReward.rewardNumber, 'java.math.BigDecimal')}) */ ?>
                             class="reward-list-item-money"
                             style="background: var(--heo-vip);">¥ [[${authorReward.amount}]]
                        </div>
                        <time class="datatime reward-list-item-time">[[${authorReward.datatime}]]</time>
                    </div>
                </div>
                <div <?php /* if(${#strings.isEmpty(authorReward.avatar)}) */ ?>>
                    <div class="reward-list-item-name">[[${authorReward.name}]]</div>
                    <div class="reward-list-bottom-group">
                        <div <?php /* if(${#conversions.convert(authorReward.amount, 'java.math.BigDecimal') < #conversions.convert(theme.config.aboutReward.rewardNumber, 'java.math.BigDecimal')}) */ ?>
                             class="reward-list-item-money">¥
                            [[${authorReward.amount}]]
                        </div>
                        <div <?php /* if(${#conversions.convert(authorReward.amount, 'java.math.BigDecimal') >= #conversions.convert(theme.config.aboutReward.rewardNumber, 'java.math.BigDecimal')}) */ ?>
                             class="reward-list-item-money"
                             style="background: var(--heo-vip);">¥ [[${authorReward.amount}]]
                        </div>
                        <time class="datatime reward-list-item-time">[[${authorReward.datatime}]]</time>
                    </div>
                </div>

            </div>

        </div>

        <th:block <?php /* if(${pluginFinder.available('plugin-afdian')}) */ ?>>
            <a href="https://afdian.com/a/carolcoral" target="_blank"><span class="sponar_afdian">爱发电</span></a>
            <div class="reward-list-all" <?php /* if(${not #lists.isEmpty(afdianFinder.listAllSponsor())}) */ ?>
                 th:with="authorRewardList = ${afdianFinder.listAllSponsor().data.list}">
                <div class="reward-list-item" <?php if (have_posts()) : while (have_posts()) : the_post(); ?>>
                    <div <?php /* if(${not #strings.isEmpty(authorReward.user.avatar)}) */ ?>>
                        <div>
                            <div class="reward-list-item-avatar">
                                <img th:src="${authorReward.user.avatar}" th:alt="${authorReward.user.name}">
                            </div>
                            <div style="z-index:20;float: left;" class="reward-list-item-avatar-group">
                                <div class="reward-list-item-name">[[${authorReward.user.name}]]</div>
                            </div>
                        </div>
                        <div class="reward-list-bottom-group">
                            <div <?php /* if(${#conversions.convert(authorReward.all_sum_amount, 'java.math.BigDecimal') < #conversions.convert(afdianFinder.getRewardNumber(), 'java.math.BigDecimal')}) */ ?>
                                 class="reward-list-item-money">¥
                                [[${authorReward.all_sum_amount}]]
                            </div>
                            <div <?php /* if(${#conversions.convert(authorReward.all_sum_amount, 'java.math.BigDecimal') >= #conversions.convert(afdianFinder.getRewardNumber(), 'java.math.BigDecimal')}) */ ?>
                                 class="reward-list-item-money"
                                 style="background: var(--heo-vip);">¥ [[${authorReward.all_sum_amount}]]
                            </div>
                            <time class="datatime reward-list-item-time">
                                [[${afdianFinder.parseTime(authorReward.last_pay_time)}]]
                            </time>
                        </div>
                    </div>
                </div>
            </div>
        </th:block>

    </div>
</div>
<style>
    span.sponar_afdian {
        font-size: 2em;
        color: antiquewhite;
    }
</style>
