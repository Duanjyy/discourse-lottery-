<!-- 我的介绍&我的想法 -->
<div class="author-content">
    <div class="author-content-item myInfoAndSayHello">
    </div>
    <div class="aboutsiteTips author-content-item"></div>
    <script>
        var pursuitInterval = null;
        pursuitInterval = setInterval(function () {
            const show = document.querySelector('span[data-show]')
            const next = show.nextElementSibling || document.querySelector('.first-tips')
            const up = document.querySelector('span[data-up]')
            if (up) {
                up.removeAttribute('data-up')
            }
            show.removeAttribute('data-show')
            show.setAttribute('data-up', '')
            next.setAttribute('data-show', '')
        }, 2000)

        document.addEventListener('pjax:send', function () {
            clearInterval(pursuitInterval);
        });
    </script>
</div>