<!-- 关注偏好&音乐偏好 -->
<div class="author-content" >

    <div class="author-content-item like-technology"
         th:style="'background: url('+ @{${theme.config.about.like.like_bg}} +') top / cover no-repeat;'">
        <div class="card-content">
            <div class="author-content-item-tips" th:text="${theme.config.about.like.like_tips}">

            </div>
            <span class="author-content-item-title"
                  th:text="${theme.config.about.like.like_title}"></span>
            <div class="content-bottom">
                <div class="tips" th:text="${theme.config.about.like.like_bottom}"></div>
            </div>
        </div>
    </div>

    <div class="author-content-item like-music"
         th:style="'background: url('+ @{${theme.config.about.music.music_bg}} +') top / cover no-repeat'">
        <div class="card-content">
            <div class="author-content-item-tips" th:text="${theme.config.about.music.music_tips}">

            </div>
            <span class="author-content-item-title"
                  th:text="${theme.config.about.music.music_title}"></span>
            <div class="content-bottom">
                <div class="tips">跟 [[<?php bloginfo("name"); ?>]] 一起欣赏更多音乐</div>
            </div>
            <div <?php /* if(${not #strings.isEmpty(theme.config.about.music.music_link)}) */ ?> class="banner-button-group">
                <a class="banner-button"
                   th:href="${theme.config.about.music.music_link}"
                   target="_blank"
                   rel="noopener nofollow">
                    <i class="haofont hao-icon-circle-arrow-up-right-1"></i>
                    <span class="banner-button-text">更多推荐</span></a>
            </div>
        </div>
    </div>

</div>