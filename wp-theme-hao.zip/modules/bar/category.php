<?php get_header(); ?>
<!-- 目录条 -->
<div id="category-bar">
    <div class="category-bar-items" id="category-bar-items">
        <div class="category-bar-item select" id="category-bar-home">
            <a href="/">首页</a>
        </div>

        <th:block th:with="categories = ${categoryFinder.listAll()}">

            <div class="category-bar-item"
                 <?php /* loop over categoryItem : ${categories} */ ?>
                 th:id="${categoryItem.spec.displayName}">
                <a th:href="@{${categoryItem.status.permalink}}" th:text="${categoryItem.spec.displayName}"></a>
            </div>

        </th:block>
    </div>
    <a class="category-bar-more" th:replace="~{modules/bar/more}">更多</a>
</div>
<?php get_footer(); ?>
