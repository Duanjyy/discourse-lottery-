<!-- 目录条，这里使用和 category-bar 同样的 css -->
<div id="category-bar">
    <div class="category-bar-items" id="category-bar-items">
        <div class="category-bar-item select" id="category-bar-home">
            <a href="/">首页</a>
        </div>

        <th:block th:with="customUrls = ${theme.config.layout.navs.navCustomUrl}">

            <div class="category-bar-item"
                 <?php /* loop over customUrlItem : ${customUrls} */ ?>
                 th:id="${customUrlItem.title}">
                <a th:href="@{${customUrlItem.url}}" th:text="${customUrlItem.title}"></a>
            </div>

        </th:block>
    </div>
    <a class="category-bar-more" th:replace="~{modules/bar/more}">更多</a>
</div>