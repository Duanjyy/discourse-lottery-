<script <?php /* if(${theme.config.footer.footerContent.style_one.runtime_enable}) */ ?> async="async">(function () {
    var grt = new Date("[[${#strings.arraySplit(theme.config.basics.siteStartTime, '-')[1]}]]/[[${#strings.arraySplit(theme.config.basics.siteStartTime, '-')[2]}]]/[[${#strings.arraySplit(theme.config.basics.siteStartTime, '-')[0]}]] 00:00:00"); //设置网站上线时间
    var now = new Date();
    var dnum;
    var hnum;
    var mnum;
    var snum;
    var nowHour;
    var t;
    var n;

    // 计算并更新天数、小时数、分钟数和秒数
    function updateTime() {
        now = new Date(); // 更新 now 的值
        nowHour = now.getHours(); // 更新 nowHour 的值
        var days = (now - grt) / 1000 / 60 / 60 / 24;
        dnum = Math.floor(days);
        var hours = (now - grt) / 1000 / 60 / 60 - 24 * dnum;
        hnum = Math.floor(hours);
        if (String(hnum).length == 1) {
            hnum = "0" + hnum;
        }
        var minutes = (now - grt) / 1000 / 60 - 24 * 60 * dnum - 60 * hnum;
        mnum = Math.floor(minutes);
        if (String(mnum).length == 1) {
            mnum = "0" + mnum;
        }
        var seconds = (now - grt) / 1000 - 24 * 60 * 60 * dnum - 60 * 60 * hnum - 60 * mnum;
        snum = Math.round(seconds);
        if (String(snum).length == 1) {
            snum = "0" + snum;
        }
        t = Math.trunc(234e8 + (now - grt) / 1e3 * 17)
        n = (t / 1496e5).toFixed(6)
    }

    // 更新网页中显示的网站运行时间
    function updateHtml() {
        const footer = document.getElementById("footer");
        if (!footer) return
        let currentTimeHtml = "";
        let img = "";
        let description = "";
        if (nowHour < 18 && nowHour >= 9) {
            // 如果是上班时间
            img = "[(${theme.config.footer.footerContent.style_one.work_img})]";
            description = "[(${theme.config.footer.footerContent.style_one.work_description})]";
        } else {
            // 如果是下班时间
            img = "[(${theme.config.footer.footerContent.style_one.offduty_img})]";
            description = "[(${theme.config.footer.footerContent.style_one.offduty_description})]";
        }
        if (document.getElementById("workboard")) {
            currentTimeHtml =  `<img class="workSituationImg boardsign" src="${img}" alt="${description}" title="${description}">
                <div id="runtimeTextTip"> 本站居然运行了 ${dnum} 天<span id='runtime'> ${hnum} 小时 ${mnum} 分 ${snum} 秒 </span><i class='haofont hao-icon-heartbeat' style='color:red'></i> <br> 旅行者 1 号当前距离地球 ${t} 千米，约为 ${n} 个天文单位 🚀 </div>`
            document.getElementById("workboard").innerHTML = currentTimeHtml;
        }
    }
    setInterval(() => {
        updateTime();
        updateHtml();
    }, 1000);
})();</script>
