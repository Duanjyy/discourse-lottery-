<!-- 动态标题 -->
<script
        th:if="${theme.config.other.diytitle.diytitleEnable}">
    var leaveTitle = '[[${theme.config.other.diytitle.leaveTitle}]]';
    var backTitle = '[[${theme.config.other.diytitle.backTitle}]]';
    var OriginTitile = "[(${siteTitle})]"
    var titleTime
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) {
            //离开当前页面时标签显示内容
            document.title = leaveTitle
            clearTimeout(titleTime)
        } else {
            //返回当前页面时标签显示内容
            document.title = backTitle + OriginTitile
            //两秒后变回正常标题
            titleTime = setTimeout(function () {
                document.title = OriginTitile
            }, 2000)
        }
    })
</script>