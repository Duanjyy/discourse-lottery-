<th:block th:fragment="bangumi-item(spec)">
    <div class="bangumi-item">
        <div class="bangumi-picture no-lightbox">
            <img
                    th:src="${isLazyload ? '' : spec.cover}"
                    th:data-lazy-src="${ isLazyload ? spec.cover : ''}"
                    referrerpolicy="no-referrer" width="110"
                    style="width:110px;margin:20px auto;">
        </div>
        <div class="bangumi-info">
            <div class="bangumi-title">
                <a target="_blank" th:href="${spec.url}">[[${spec.title}]]</a>
            </div>
            <div class="bangumi-meta">
                <span class="bangumi-info-items">
                    <span class="bangumi-info-item">
                        <span class="bangumi-info-total">[[${spec.totalCount}]]</span>
                        <em class="bangumi-info-label-em">0</em>
                    </span>
                    <span class="bangumi-info-item bangumi-area">
                        <span class="bangumi-info-label">[[${spec.type}]]</span>
                        <em th:text="${#strings.isEmpty(spec.score)? '未知' :spec.area}"></em>
                    </span>
                    <span class="bangumi-info-item bangumi-play">
                        <span class="bangumi-info-label">总播放</span>
                        <em th:text="${#strings.isEmpty(spec.score)? '未知' :spec.view}"></em>
                    </span>
                    <span class="bangumi-info-item bangumi-follow">
                        <span class="bangumi-info-label">追番人数</span>
                        <em th:text="${#strings.isEmpty(spec.score)? '未知' :spec.follow}"></em>
                    </span>
                    <span class="bangumi-info-item bangumi-coin">
                        <span class="bangumi-info-label">硬币数</span>
                        <em th:text="${#strings.isEmpty(spec.score)? '未知' :spec.coin}"></em>
                    </span>
                    <span class="bangumi-info-item bangumi-danmaku">
                        <span class="bangumi-info-label">弹幕总数</span>
                        <em th:text="${#strings.isEmpty(spec.score)? '未知' :spec.danmaku}"></em>
                    </span>
                    <span class="bangumi-info-item bangumi-info-item-score">
                        <span class="bangumi-info-label">评分</span>
                        <em th:text="${#strings.isEmpty(spec.score)? '暂无' :spec.score}"></em>
                    </span>
                </span>
            </div>
            <div class="bangumi-comments">
                <p>[[${spec.des}]]</p>
            </div>
        </div>
    </div>
</th:block>
