<div th:fragment="author-content(background, smallTitle, bigTitle, detail,buttonUrl,buttonTitle)"
     class="author-content author-content-item essayPage single"
     th:style="'background:url('+${background}+') left 28% / cover no-repeat !important;'">
    <div class="card-content">
        <div class="author-content-item-tips" th:text="${smallTitle}"></div>
        <span class="author-content-item-title" th:text="${bigTitle}"></span>
        <div class="content-bottom">
            <div class="tips" th:text="${detail}"></div>
        </div>
        <div class="banner-button-group" th:if="${not #strings.isEmpty(buttonUrl)}">
            <a class="banner-button" target="_blank" th:href="${buttonUrl}">
                <i class="haofont hao-icon-circle-arrow-right"></i>
                <span class="banner-button-text" th:text="${buttonTitle}"></span>
            </a>
        </div>
    </div>
</div>
