<!DOCTYPE html>
<html 
      th:replace="~{modules/layouts/layout :: layout(content = ~{::content}, htmlType = 'about',title = ${singlePage.spec.title + ' | ' + site.title}, head = ~{::head})}">
<th:block th:fragment="head">
    <th:block th:replace="~{modules/common/open-graph :: open-graph(_title = ${singlePage.spec.title},
                _permalink = ${singlePage.status.permalink},
                _cover = ${singlePage.spec.cover},
                _excerpt = ${singlePage.status.excerpt},
                _type = 'website')}"></th:block>
</th:block>
<th:block th:fragment="content">
    
    <div class="page" id="body-wrap">
        
        <!-- 头部导航栏 -->
        <header class="not-top-img" id="page-header">
            <nav th:replace="~{modules/nav :: nav(title = ${singlePage.spec.title})}"></nav>
        </header>
        <main class="layout hide-aside" id="content-inner">
            <div id="page">
                
                <div id="about-page">
                    
                    
                    <div class="author-info">
                        <div class="author-tag-left"
                             <?php /* if(${not #lists.isEmpty(theme.config.about.author_info_left_tags)}) */ ?>
                             th:with="authorTags = ${theme.config.about.author_info_left_tags}">
                            <span class="author-tag" <?php /* loop */ ?>
                                  th:text="${authorTag}"></span>
                        </div>
                        <div class="author-img">
                            <th:block th:with="
                                    defaultImg = ${assets_link + '/images/hao-logo.jpg'},
                                    finalImg = ${#strings.isEmpty(theme.config.about?.aboutAuthorImage)
                                               ? defaultImg
                                               : theme.config.about.aboutAuthorImage}
                                ">
                                <img th:src="${finalImg}">
                            </th:block>
                        </div>
                        <div class="author-tag-right"
                             <?php /* if(${not #lists.isEmpty(theme.config.about.author_info_right_tags)}) */ ?>
                             th:with="authorTags = ${theme.config.about.author_info_right_tags}">
                            <span class="author-tag" <?php /* loop */ ?>
                                  th:text="${authorTag}"></span>
                        </div>
                    </div>
                    <div class="author-title" th:text="${singlePage.spec.title}"></div>
                    
                    <th:block
                            th:replace="~{modules/about-widgets :: about-widgets(${theme.config.about.widget_list})}"></th:block>
                    
                    <div class="author-content">
                        <div class="create-site-post author-content-item single" th:utext="${theme.config.about.xjlc}">
                        </div>
                    </div>
                    
                    <th:block <?php get_template_part("modules/widgets/about-widgets/tenyear"); ?>></th:block>
                    
                    <th:block <?php get_template_part("modules/widgets/about-widgets/about-reward"); ?>></th:block>
                
                </div>
                
                <th:block <?php /* if(${theme.config.about.tenyear.tenyear_enable}) */ ?>>
                    <link rel="stylesheet" th:href="${assets_link + '/css/tenyear.css' + theme_version}" media="all"
                          onload="this.media='all'">
                    <script> (() => {
                        let t = document.querySelector(".progress"),
                                n = document.querySelector(".past-time"),
                                o = document.querySelector(".percentage-label"),
                                r = document.querySelector(".start-time"),
                                s = document.querySelector(".end-time"),
                                a = new Date("[(${theme.config.about.tenyear.start_time})]").getTime(),
                                i = new Date("[(${theme.config.about.tenyear.end_time})]").getTime(),
                                c = ((new Date).getTime() - a) / (i - a) * 100,
                                u = c <= 100 ? c + "%" : "100%",
                                m = c <= 100 ? c.toFixed(0) + "%" : "已达标 ";
                        if (c < 10){
                            m = "";
                        }
                        n.style.setProperty("--past-time-percentage", c + "%"), t.style.setProperty("--progress-percentage", u), o.textContent = m, o.style.left = `calc(${c}% - 3rem)`, r.textContent = "" + new Date(a).toLocaleDateString(), s.textContent = "" + new Date(i).toLocaleDateString(), setTimeout(() => {
                            o.style.visibility = "visible"
                        }, 2500);
                    })()
                    </script>
                </th:block>
            
            
            </div>
        
        </main>
        <!-- 底部 -->
        <footer <?php get_template_part("modules/footer"); ?>/>
    </div>

</th:block>

</html>
