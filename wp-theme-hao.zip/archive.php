<?php get_header(); ?>


    <div class="page" id="body-wrap">
        <header class="not-top-img" id="page-header">
            <?php get_template_part("modules/nav"); ?>
        </header>
        <main class="layout" id="content-inner">
            <!-- archive -->
            <div id="archive">
                <div class="article-sort-title">文章<sup>[[${siteStatsFinder.getStats().post}]]</sup></div>
                <div class="article-sort" <?php /* loop over archive : ${archives.items} */ ?>
                     th:with='postRandomImg=${#strings.contains(theme.config.layout.postRandomImg,"?") ? theme.config.layout.postRandomImg+"&" : theme.config.layout.postRandomImg+"?"}'>
                    <div class="article-sort-item year" th:text="${archive.year}"></div>
                    <div class="article-sort" <?php /* loop over month : ${archive.months} */ ?>>
                        <!-- 月份没有样式所以不显示 -->
                        <!-- <div class="article-sort-item" th:text="${month.month}"></div> -->
                        <div class="article-sort-item" <?php /* loop over post : ${month.posts} */ ?>>
                            <a class="article-sort-item-img" th:href="@{<?php the_permalink(); ?>}"
                               th:title="<?php the_title(); ?>">
                                <img th:alt="<?php the_title(); ?>"
                                     th:src="${#strings.isEmpty(post.spec.cover) ? postRandomImg+post.spec.title : thumbnail.gen(post.spec.cover, 's')}">
                            </a>
                            <div class="article-sort-item-info">
                                <div class="article-sort-item-time"><i class="far fa-calendar-alt"></i>
                                    <time class="post-meta-date-created"
                                          th:attr="datetime=${#dates.format(post.spec.publishTime,'yyyy-MM-dd HH:mm:ss')}"
                                          th:text="${#dates.format(post.spec.publishTime,'yyyy-MM-dd')}"
                                          th:title="'创建于' + ${#dates.format(post.spec.publishTime,'yyyy-MM-dd HH:mm:ss')}">
                                    </time>
                                </div>
                                <a class="article-sort-item-title" onclick="window.event.cancelBubble=!0"
                                   th:href="@{<?php the_permalink(); ?>}" th:text="<?php the_title(); ?>"
                                   th:title="<?php the_title(); ?>"></a>
                                <div class="article-sort-item-tags">
                                    <a class="article-meta__tags"
                                       <?php /* loop over tag : ${post.tags} */ ?> th:href="@{${tag.status.permalink}}">
                                        <span class="tags-punctuation">[[${tag.spec.displayName}]]</span>
                                    </a>
                                    <span class="article-meta__link">•</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- 分页 -->
                <?php get_template_part("modules/widgets/page"); ?>
            </div>
            <!-- sidebar -->
            <?php get_template_part("modules/aside"); ?>
        </main>
        <!-- 底部 -->
        <?php get_template_part("modules/footer"); ?>
    </div>


<?php get_footer(); ?>
